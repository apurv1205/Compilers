#ifndef __ASS6_14CS10001_TRANSLATOR_H
#define __ASS6_14CS10001_TRANSLATOR_H
#define _GLIBCXX_USE_CXX11_ABI 0
#include <bits/stdc++.h>
#define size_of_char 		1
#define size_of_int  		4
#define size_of_double		8
#define size_of_pointer		4


extern  char* yytext;
extern int yyparse();

using namespace std;

/****Declarations****/

typedef std::list<int> lint;

enum data_type{
	VOID,INT,DOUBLE,CHAR,PTR,ARR,FUNCTION
};

enum op_type{
	// arithmetic operations
	ADD,SUB,MUL,DIV,MOD,LSHIFT,RSHIFT,BITAND,BITOR,XOR,AND,OR,
	// Comparison
	LT,GT,LTE,GTE,EQop,NEQop,GOTO, RETURN,
	// Unary Operators
	UMINUS, UPLUS, ADDRESS, RIGHT_POINTER, BITNOT, LNOT, //Logical Not
	// PTR Assign
	PTRL, PTRR,
	// ARR Assign
	ARRR, ARRL,
	// Function call
	PARAM, CALL, FUNCSTART, FUNCEND,
	//Equal
	EQUAL,EQUALstr,EQUALchar,
	//CONVRSION operations
	INT2DOUBLE,CHAR2DOUBLE,CHAR2INT,INT2CHAR,DOUBLE2CHAR,DOUBLE2INT

};


struct quad;
struct quads;
struct type_spec;
struct sym_entry;
struct symtab;



/*******Struct definitions**********/
// struct name: quad
// data: operation_type, result string, argument1, argument2 names
// functions: constructor, update(for address update) and print

struct  quad{

	op_type op;
	std::string result;
	std::string arg1;
	std::string arg2;

	//functions
	quad(op_type op,std::string result,std::string arg1="",std::string arg2="");
	void update(int addr);
	void print(int &a);

};


// struct name: quads
// data: array of quads
// functions: constructor, print
struct quads{

	std::vector<quad> quadarr;

	//functions
	quads(){quadarr.reserve(1000);}
	void print();
	//void emit(quad q);
};


// struct name: type_spec
// data: base type, pointer ot subtype and size
// functions: constructor and print 
struct type_spec{

	data_type type;
	int width;
	type_spec *ptr;                 

	//functions
	type_spec(data_type x = INT,type_spec *next=NULL,int width = 1);	
	void print();
};


// struct name: sym_entry
// data: name, pointer to type, inital value, size of symbol, offset in symbol table, pointer ot nested symbol table, category = {"global","local","function","parameter"}
// functions: constructor, update type, initialize, print and linkst(for linking to a nested symbol table)
struct sym_entry{

	string name;
	type_spec *type;
	string init;
	int width;
	int offset;
	symtab *nest_table;
	string category;


	// functions
	sym_entry(string name, data_type t=INT, type_spec* next = NULL, int width = 0);

	void update_type(type_spec *t);
	void initialize(std::string t);
	//sym_entry(std::string name="",type_spec *type=NULL,std::string init="",symtab *nest_table=NULL);
	void print();
	void linkst(symtab* t);
};


// struct name: symtab
// data: name, table of symbols, count of temporary variables, pointer to parent symbol table
// functions: constructor, update_offset(to calculate offset of symbols  in symbol table),search(a symbol) and print
struct symtab{

	std::string name;
	std::vector<sym_entry> table;
	int temp_count;
	symtab *parent;
	// Activation Record
	map<std::string, int> activate; 

	// functions
	symtab(string name="global",symtab *parent=NULL);
	void update_offset();
	bool search(string a);
	void print();
	

};


// these methods have been described in .cpp file
void emit(std::string result,op_type op,std::string arg1="",std::string arg2="");
sym_entry *lookup(symtab* cst,std::string a);


sym_entry *gentemp(type_spec t,std::string init="");
lint makelist(int num);
lint merge(lint a,lint b);
void backpatch(lint p,int i);
bool typecheck(sym_entry *E1,sym_entry *E2,sym_entry **t1,sym_entry ** t2);
//bool typecheck(data_type *p1,data_type *p2);
bool convert(sym_entry *e1,sym_entry *e2,sym_entry **t1,sym_entry ** t2);
int compute_size(data_type t,type_spec *type,int width);


sym_entry* x2Int(sym_entry *);
sym_entry* x2Double(sym_entry *);
sym_entry* x2Char(sym_entry *);

// Expression struct
// data : bool isbool(for boolean expression)
//        bool isarr(for storing array)
//        bool isptr(for storing pointer) 

typedef struct expr
{

	bool isbool;
	bool isarr;
	bool isptr;

	// if boolean 
	lint truelist;
	lint falselist;

	// if statement
	sym_entry *loc;

	expr();

}expr;




// statement struct
struct stmt{
	lint nextlist;           // store list of goto's
	
};


// struct Array
// data : 1) symbol for storing base array
//		  2) type of base array
//		  3) symbol for storing expression	
struct arr{
	sym_entry *array;
	type_spec type;
	sym_entry *loc;
};

typedef struct  stmt stmt;
typedef struct arr arr;
//typedef struct  exp exp;




// helper functions
int nextinstr();

void conv2bool (expr *t);				// convert any expression to bool
void conv2exp (expr *t);         // convert bool to expression



// helper function to convert a particular data type to string
template <typename T> std::string tostr(const T& t) { 
	ostringstream os; 
	os<<t; 
	return os.str(); 
} 



/* Global variables */
extern symtab* currentST;			// Current Symbbol Table
extern symtab* globalST;			// Global Symbbol Table
extern quads *quadtrain;				// Quads
extern sym_entry* symname;	
extern type_spec TYPE;              // global for type variable
extern arr* globarr;
extern sym_entry *globptr;
extern std::map<string, int>  strings;
#endif
