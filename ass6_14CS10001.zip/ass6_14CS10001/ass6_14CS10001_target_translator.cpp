
#include "ass6_14CS10001_translator.h"
#include <bits/stdc++.h>
using namespace std;


extern int yylex();
extern FILE *yyin;
extern char *yytext;
int globallabel = 100;

symtab *table;
int counter = 0;
void computeActivationRecord(symtab *table)
{
	int param = 16;
	int local = -8;
	for(vector<sym_entry>::iterator it=table->table.begin();it!=table->table.end();it++)
	{
		if(strcmp(it->category.c_str(),"param")==0)
		{
			
			table->activate[it->name] = param;
			param += 8;
		}
		else if(strcmp(it->category.c_str(),"local")==0)
		{
			
			table->activate[it->name] = local;
			if(it->width>8)
				local -= (it->width);
			else
				local -= 8;
		}
	}
}

inline bool isInteger(const std::string & s)
{
   if(s.empty() || ((!isdigit(s[0])) && (s[0] != '-') && (s[0] != '+'))) return false ;

   char * p ;
   strtol(s.c_str(), &p, 10) ;

   return (*p == 0) ;
}



std::map<int,int> labels;
std::vector<string> params;



void printquad(quad *comp)
{

	string result = comp->result;
	string arg1 = comp->arg1;
	string arg2 = comp->arg2;
	int min = 0;
	
	switch(comp->op)
	{
		case(ADD):				cout<<"\tmovq\t "<<table->activate[arg1]<<"(%rbp), %rax\n";
								if(isInteger(arg2))
									cout<<"\taddq\t $"<<arg2.c_str()<<", %rax\n";
								else
									cout<<"\taddq\t"<<table->activate[arg2]<<"(%rbp),%rax\n";
								cout<<"\tmovq\t %rax, "<<table->activate[result]<<"(%rbp)\n";
								break;


		case(SUB):				cout<<"\tmovq\t "<<table->activate[arg1]<<"(%rbp), %rax\n";
								if(isInteger(arg2))
									cout<<"\tsubq\t $"<<arg2.c_str()<<", %rax\n";
								else
									cout<<"\tsubq\t"<<table->activate[arg2]<<"(%rbp),%rax\n";
								cout<<"\tmovq\t %rax, "<<table->activate[result]<<"(%rbp)\n";
								break;


		case(MUL):				cout<<"\tmovq\t "<<table->activate[arg1]<<"(%rbp), %rax\n";
								if(isInteger(arg2))
									cout<<"\timulq\t $"<<arg2.c_str()<<", %rax\n";
								else
									cout<<"\timulq\t"<<table->activate[arg2]<<"(%rbp),%rax\n";
								cout<<"\tmovq\t %rax, "<<table->activate[result]<<"(%rbp)\n";
								break;


		case(DIV):				cout<<"\tmovq\t "<<table->activate[arg1]<<"(%rbp), %rax\n";
								cout<<"\tcltq\n";
								if(isInteger(arg2))
									cout<<"\tidivq\t $"<<arg2.c_str()<<", %rax\n";
								else
									cout<<"\tidivq\t"<<table->activate[arg2]<<"(%rbp), %rax\n";
								cout<<"\tmovq\t %rax, "<<table->activate[result]<<"(%rbp)\n";
								break;

		case(EQUAL):
								if(isInteger(arg1))
									cout<<"\tmovq\t $"<<arg1.c_str()<<", %rax\n";
								else
									cout<<"\tmov\t "<<table->activate[arg1]<<"(%rbp), %rax\n";

								cout<<"\tmovq\t %rax, "<<table->activate[result]<<"(%rbp)\n";
								break;



		case(EQUALstr):
								cout<<"\tmovq\t$.LC"<<strings[arg1]<<", "<<table->activate[result] << "(%rbp)\n";
								break;


		case(EQUALchar):
								cout << "movb\t$" << arg1.c_str() << ", " << table->activate[result] << "(%rbp)\n";
								break;






		case(EQop):
								cout<<"\tmovq\t "<<table->activate[arg1]<<"(%rbp), %rax\n";
								cout<<"\tcmpq\t "<<table->activate[arg2]<<"(%rbp), %rax\n";
								cout<<"\tje\t.Label"<<labels[atoi(result.c_str())]<<"\n";
								break;

		case(NEQop):
								cout<<"\tmovq\t "<<table->activate[arg1]<<"(%rbp), %rax\n";
								cout<<"\tcmpq\t "<<table->activate[arg2]<<"(%rbp), %rax\n";
								cout<<"\tjne\t.Label"<<labels[atoi(result.c_str())]<<"\n";
								break;


		case(LT):
								cout<<"\tmovq\t "<<table->activate[arg1]<<"(%rbp), %rax\n";
								cout<<"\tcmpq\t "<<table->activate[arg2]<<"(%rbp), %rax\n";
								cout<<"\tjl\t.Label"<<labels[atoi(result.c_str())]<<"\n";
								break;


		case(GT):
								cout<<"\tmovq\t "<<table->activate[arg1]<<"(%rbp), %rax\n";
								cout<<"\tcmpq\t "<<table->activate[arg2]<<"(%rbp), %rax\n";
								cout<<"\tjg\t.Label"<<labels[atoi(result.c_str())]<<"\n";
								break;


		case(LTE):
								cout<<"\tmovq\t "<<table->activate[arg1]<<"(%rbp), %rax\n";
								cout<<"\tcmpq\t "<<table->activate[arg2]<<"(%rbp), %rax\n";
								cout<<"\tjle\t.Label"<<labels[atoi(result.c_str())]<<"\n";
								break;


		case(GTE):
								cout<<"\tmovq\t "<<table->activate[arg1]<<"(%rbp), %rax\n";
								cout<<"\tcmpq\t "<<table->activate[arg2]<<"(%rbp), %rax\n";
								cout<<"\tjge\t.Label"<<labels[atoi(result.c_str())]<<"\n";
								break;


		case(GOTO):
								cout<<"\tjmp\t.Label"<<labels[atoi(result.c_str())]<<"\n";
								break;

		case(ADDRESS):
								cout<<"\tleaq\t "<<table->activate[arg1]<<"(%rbp), %rax\n";
								cout<<"\tmovq\t %rax, "<<table->activate[result]<<"(%rbp)\n";
								break;

		case(PTRR):
								cout<<"\tmovq\t "<<table->activate[arg1]<<"(%rbp), %rax\n";
								cout<<"\tmovq\t 0(%rax), %rcx\n";
								cout<<"\tmovq\t %rcx, "<<table->activate[result]<<"(%rbp)\n";
								break;

		case(PTRL):
								cout<<"\tmovq\t "<<table->activate[arg1]<<"(%rbp), %rcx\n";
								cout<<"\tmovq\t "<<table->activate[result]<<"(%rbp), %rax\n";
								cout<<"\tmovq\t %rcx, 0(%rax)\n";
								break;


		case(UMINUS):			cout << "\tnegq\t " << table->activate[arg1] << "(%rbp)\n";
								break;


		case ARRR: 
								cout << "\tmovq\t" << table->activate[arg2] << "(%rbp), "<<"%rax" << endl;
								cout<< "\tnegq\t %rax \n";
								cout << "\tmovl\t" << table->activate[arg1] << "(%rbp,%rax,1), "<<"%eax" << endl;
								cout << "\tcltq\n";
								cout << "\tmovq \t%rax, " <<  table->activate[result] << "(%rbp)" << endl;
								break;
			 			
		case ARRL: 
								cout << "\tmovq\t" << table->activate[arg1] << "(%rbp), "<<"%rax" << endl;
								cout<< "\tnegq\t %rax \n";
								cout << "\tmovq\t" << table->activate[arg2] << "(%rbp), "<<"%rdx" << endl;
								cout << "\tmovl\t" << "%edx, " << table->activate[result] << "(%rbp,%rax,1)" << endl;
								break;


		case(RETURN):
								if(result!="")
										cout<<"\tmovq\t "<<table->activate[result]<< "(%rbp), %rax\n";
								cout<<"\tjmp .Label"<<globallabel<<"\n";

								break;

		
		case(PARAM):			
								params.push_back(result);
								break;
		
		case(CALL):

								if(strcmp(arg1.c_str(),"readi")==0 || strcmp(arg1.c_str(),"printi")==0 || strcmp(arg1.c_str(),"prints")==0)
								{
									for(vector<string>::reverse_iterator rit = params.rbegin();rit!=params.rend();rit++)
									{
										cout<<"\tmov\t "<<table->activate[*rit]<<"(%rbp), %rdi\n";
									}
									cout<<"\tcall "<<arg1.c_str()<<"\n";
									cout<<"\tmovq\t %rax, "<< table->activate[result] <<"(%rbp)\n";
								} 

								else{
									for(vector<string>::reverse_iterator rit = params.rbegin();rit!=params.rend();rit++)
									{
										cout<<"\tmovq\t "<<table->activate[*rit]<<"(%rbp), %rax\n";
										cout<<"\tmovq %rax,-8(%rsp)\n";
										cout<<"\tsubq $8, %rsp\n";
									}
									cout<<"\tcall "<<arg1.c_str()<<"\n";
									cout<<"\tmovq\t %rax, "<< table->activate[result] <<"(%rbp)\n";
									cout<<"\taddq \t$"<<params.size()*8<<", %rsp\n";
								}
								params.clear();
								break;
								


		case(FUNCSTART):
								cout<<"\t.globl\t"<<result.c_str()<<"\n";                           
								cout<<"\t.type\t"<<	result.c_str()<<", @function\n";                   
								cout<<result.c_str()<<":\n";                                         
								cout<<".LFB"<<counter<<":\n";
								cout<<"\t.cfi_startproc\n"; 
								cout<<"\tpushq	%rbp\n";                                 
								cout<<"\t.cfi_def_cfa_offset 16\n";
								cout<<"\t.cfi_offset 6, -16\n";
								cout<<"\tmovq\t	%rsp, %rbp\n";                                          
								cout<<"\t.cfi_def_cfa_register 6\n";

								table = lookup(globalST,result)->nest_table;	
								//cout<<"\tsubq $"<< table->table.back().offset <<" ,%rsp\n";
								min=0;
								for(std::map<string, int>::iterator it = table->activate.begin();it!=table->activate.end();it++)
									if(it->second < min) min = it->second;
								cout<<"\tsubq $"<< -min  <<" ,%rsp\n";
								break; 

		case(FUNCEND):			
								
								//cout<<"\taddq\t$"<<lookup(globalST,result)->nest_table->table.back().offset<<", %rsp\n";
								//cout<<"\tpop	%rbp \n"; 
								cout<<".Label"<<globallabel<<":\n";
								globallabel = 2*globallabel; 
								cout<<"\tleave\n";                             
								cout<<"\t.cfi_def_cfa 7, 8\n";
								cout<<"\tret\n";                                          
								cout<<"\t.cfi_endproc\n";
								cout<<".LFE"<<counter++<<":\n";
								cout<<"\t.size "<<result.c_str()<<", .-"<<result.c_str()<<"\n";
								break;
		default:
								break;
								
	}
}



void maplabels()
{
	int count = 0;
	for(vector<quad>::iterator it=quadtrain->quadarr.begin();it != quadtrain->quadarr.end();it++)
	{
		switch(it->op)
		{
			case(LT):
			case(GT):
			case(LTE):
			case(GTE):
			case(GOTO):
			case(EQop):
			case(NEQop):
						labels[atoi(it->result.c_str())] = 1;
						break;
			default:
						break;
		}
	}

	for(std::map<int, int>::iterator it=labels.begin();it!=labels.end();it++)
		it->second = count++;
}

void generate()
{
	cout<<"\t.file	\"ass6_14CS10001.c\"\n";            			
	

	for(vector<sym_entry>::iterator it = globalST->table.begin();it!=globalST->table.end();it++)
	{
		if(it->category!="FUNCTION" && it->type->type == CHAR)
		{
			if(it->init!=""){
				cout<<"\t.globl\t"<<it->name.c_str()<<"\n";
				cout<<"\t.type	"<<it->name.c_str()<<", @object\n";
				cout<<"\t.size	"<<it->name.c_str()<<", 1\n";
				cout<<it->name<<":\n";
				cout<<"\t.byte	"<<it->init.c_str()<<"\n";
			}
			else{
				cout<<".comm	"<<it->name.c_str()<<",4,4\n";	
			}
		} 

		else if(it->category!="FUNCTION" && it->type->type == INT)
		{

			if(it->init!=""){
				cout<<"\t.globl\t"<<it->name.c_str()<<"\n";
				cout<<"\t.data\n";
				cout<<"\t.align 4\n";
				cout<<"\t.type	"<<it->name.c_str()<<", @object\n";
				cout<<"\t.size	"<<it->name.c_str()<<", 4\n";
				cout<<it->name<<":\n";
				cout<<"\t.long	"<<it->init.c_str()<<"\n";
			}
			else {
				cout<<".comm\t"<<it->name.c_str()<<",4,4\n";
			}
		}
	}



	if(strings.size()!=0){
		cout<<"\t.section	.rodata\n"	;				  			
		cout<<"\t.align 8\n";	

		int count = 0;

		for (std::map<string,int>::iterator it=strings.begin(); it!=strings.end(); ++it)
		{	cout<<".LC"<<count<<":\n";
			it->second = count++;
			cout<<".string\t"<<it->first.c_str()<<"\n"; 
		}
	}


	for(vector<sym_entry>::iterator it=globalST->table.begin();it!=globalST->table.end();it++)
	{
		globalST->activate[it->name] = 0;
	}

	for(vector<sym_entry>::iterator it = globalST->table.begin();it!=globalST->table.end();it++)
	{
		if(it->category == "FUNCTION")
			computeActivationRecord(it->nest_table);
	}

	maplabels();

	cout<<"\t.text\n";
	for(vector<quad>::iterator it=quadtrain->quadarr.begin();it != quadtrain->quadarr.end();it++)
	{
		if(labels.find(it-quadtrain->quadarr.begin())!=labels.end())
			cout<<".Label"<<labels[it-quadtrain->quadarr.begin()]<<":\n";
		printquad(&*it);
	}


	cout<<"\t.ident	\"GCC: (Ubuntu 4.9.2-10ubuntu13) 4.9.2\"\n";
	cout<<"\t.section	.note.GNU-stack,\"\",@progbits\n";
}



int main()
{
	yyparse();
	printf("\n\nQuadarray  \n");
	printf("................................................................................................................................................\n\n\n");
	quadtrain->print();

	printf("\n\n\nSymbol Tables \n");
	printf("................................................................................................................................................\n\n\n");
	globalST->print();

	table = globalST;
	printf("................................................................................................................................................\n\n\n");
	generate();
}



