
int printi(int a);
int prints(char *arr);
int readi(int *ep);

int multiply(int a)
{
	a = a*2;
	return a;
}

/*This computes a* 2^a*/
int main()
{
	int p[50], n,j, a,b, suma,sumb,x;
	char *ab="suma = ";
	char *ab2= "sumb = ";	
	char *cd= " ";
	char *de= "Enter the element a: ";
	char *fg="\n";
	char *gh ="Enter the element b: ";
	  	
	x=prints(de);
  	a = readi(&x);
	x=prints(gh);
	b = readi(&x);
	suma = a;
	sumb = b;
 	while(a>0 || b>0)
	{
	    if(a<b)
		{
			sumb = multiply(sumb);
			b = b-1;
			
		}	
	     else
		{
			suma = multiply(suma);
			a = a-1;
		}	
	}
	x=prints(ab);
	x=printi(suma);
	x=prints(fg);
	x=prints(ab2);
	x=printi(sumb);
	x=prints(fg);
		
	return 0;
}


