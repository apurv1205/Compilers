int printi(int a);
int prints(int a);
int readi(int *ep);

// Selection sort
int main()
{
   int array[100], n, c, d, position, swap,temp;
   int x;

   x = prints("Enter number of elements\n");
   n = readi(&x);
 
   x = prints("Enter integers\n");
 
   for (c = 0; c < n; c++)
	{
		x = prints("Enter the elements: ");
		array[c] = readi(&x);
	}
 
   x = prints("Array elements are:\n");
    for ( c = 0 ; c < n ; c++ )
      x = printi( array[c]);

   for ( c = 0 ; c < ( n - 1 ) ; c++ )
   {
      position = c;
 
      for ( d = c + 1 ; d < n ; d++ )
      {
         if ( array[position] > array[d] )
            position = d;
      }
      if ( position != c )
      {
         swap = array[c];
         temp = array[position];
	 array[c] = temp; 
         array[position] = swap;
      }
   }
 
  x = prints("Sorted list in ascending order:\n");
 
   for ( c = 0 ; c < n ; c++ )
      x = printi( array[c]);
 
   return 0;
}
