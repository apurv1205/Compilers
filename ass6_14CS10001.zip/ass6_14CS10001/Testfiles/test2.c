int printi(int x);
int readi(int *ep);
int prints(char *buff);

// Insertion sort
int main()
{
	int p[50], n,j, i, d, temp,temp1;
	char *ab="Enter number of elements\n";
	char *bc="Sorted list in ascending order:\n";
	char *cd= " ";
	char *de= "Enter the elements: ";
	char *ef="The array is: ";
	char *fg="\n";
	
  	int x = prints(ab);
  	n = readi(&x);
 
  for (i = 0; i < n; i++)
	{
		x = prints(de);
		p[i] = readi(&x);
	}
	x = prints(ef);	
    for (i = 0; i < n; i++)
	{
		x = printi(p[i]);
		//x = prints(cd);	

	}
	prints(fg);

  for (i = 0 ; i <  n - 1 ; i++)
  {
    for (j = 0 ; j < n - i - 1; j++)
    {
      if (p[j] > p[j+1]) 
      {
        temp       = p[j];
	temp1	   = p[j+1];
        p[j]   = temp1;
        p[j+1] = temp;
	
      }
    }
  }
 
  prints(bc);
 
  for ( i = 0 ; i < n ; i++ )
{
	     x = printi(p[i]);
	    // x = prints(cd);	
}
	     x = prints(fg);	

 
	return 0;
}
