
int printi(int a);
int prints(char *ar);

int main()
{

	char *a3 = "a = b + 2\n";
	char *a4 = "a = b-2\n";
	char *a5 = "a = b*2\n";
	

	char *a8 = "Elements of array are\n";
	char *a9 = "arr[i] = i*i\n";
	

	char *a1 = "a=";
	char *a2 = "b=";
	int x;
	int a,b;
	a = 2;
	x = prints(a1);
	x = printi(a);
	b = 4;
	x = prints(a2);
	x = printi(b);

	a = b + 2;
	x = prints(a3);
	x = prints(a1);
	x = printi(a);

	
	
	a = b - 2;
	x = prints(a4);
	x = prints(a1);
	x = printi(a);


	a = b * 2;
	x = prints(a5);
	x = prints(a1);
	x = printi(a);


	


	


	int x;
	int arr[10];
	int i;
	for(i=0;i<10;i++)
		arr[i] = i*i;

	
	x = prints(a8);	
	x = prints(a9);	

	for(i=0;i<10;i++)
	{
		
		x = printi(arr[i]);
		
	}

	return 0;
}


