
#include "ass6_14CS10001_translator.h"
using namespace std;


// global variables
quads *quadtrain;   // pointer to array of quads
symtab *globalST; //global symbol table
symtab *currentST; // current symbol table
sym_entry *symname; // used for func name 
type_spec TYPE; // global for type variable
arr *globarr;  // global for holding array 
sym_entry* globptr; //global for holding pointer
map<string,int> strings;



// constructor of quad
// input: operation type, result, argument1, argument2
quad::quad(op_type op,string result,string arg1,string arg2):op(op),result(result),arg1(arg1),arg2(arg2){}


// update result during backpatch
// input: address of quad
void quad::update(int addr)
{
	this->result = tostr(addr);
}

// print quad
// input: instruction number
void quad::print(int &a)
{
	printf("	%d:	",a);
	switch(this->op)
	{
		// arithmetic operations
		case ADD:			printf("%s = %s + %s\n",result.c_str(),arg1.c_str(),arg2.c_str());break;
		case SUB:			printf("%s = %s - %s\n",result.c_str(),arg1.c_str(),arg2.c_str());break;
		case MUL:			printf("%s = %s * %s\n",result.c_str(),arg1.c_str(),arg2.c_str());break;
		case DIV:			printf("%s = %s / %s\n",result.c_str(),arg1.c_str(),arg2.c_str());break;
		case MOD:			printf("%s = %s %% %s\n",result.c_str(),arg1.c_str(),arg2.c_str());break;
		case LSHIFT:		printf("%s = %s << %s\n",result.c_str(),arg1.c_str(),arg2.c_str());break;
		case RSHIFT:		printf("%s = %s >> %s\n",result.c_str(),arg1.c_str(),arg2.c_str());break;
		case BITAND:		printf("%s = %s & %s\n",result.c_str(),arg1.c_str(),arg2.c_str());break;
		case BITOR:			printf("%s = %s | %s\n",result.c_str(),arg1.c_str(),arg2.c_str());break;
		case XOR:			printf("%s = %s ^ %s\n",result.c_str(),arg1.c_str(),arg2.c_str());break;
		case AND:			printf("%s = %s && %s\n",result.c_str(),arg1.c_str(),arg2.c_str());break;
		case OR:			printf("%s = %s || %s\n",result.c_str(),arg1.c_str(),arg2.c_str());break;
		
		// comparison operations
		case LT:  			printf("if %s < %s goto %s\n",arg1.c_str(),arg2.c_str(),result.c_str());break;
		case GT:			printf("if %s > %s goto %s\n",arg1.c_str(),arg2.c_str(),result.c_str());break;
		case LTE:			printf("if %s <= %s goto %s\n",arg1.c_str(),arg2.c_str(),result.c_str());break;
		case GTE:			printf("if %s >= %s goto %s\n",arg1.c_str(),arg2.c_str(),result.c_str());break;
		case EQop:			printf("if %s == %s goto %s\n",arg1.c_str(),arg2.c_str(),result.c_str());break;
		case NEQop:			printf("if %s != %s goto %s\n",arg1.c_str(),arg2.c_str(),result.c_str());break;
		case GOTO:			printf("goto %s\n",result.c_str());break;
		case RETURN:		
							if(result!="")
								printf("return %s\n",result.c_str());
							else
								printf("return\n");
							break;
		// Unary operators
		case UMINUS:		printf("%s = -%s\n",result.c_str(),arg1.c_str());break;
		case UPLUS:			printf("%s = +%s\n",result.c_str(),arg1.c_str());break;
		case ADDRESS:		printf("%s = &%s\n",result.c_str(),arg1.c_str());break;
		case RIGHT_POINTER:		printf("%s = %s -> %s\n",result.c_str(),arg1.c_str(),arg2.c_str());break;
		case BITNOT:		printf("%s = ~%s\n",result.c_str(),arg1.c_str());break;
		case LNOT:			printf("%s = !%s\n",result.c_str(),arg1.c_str());break;

		// ptr assign
		case PTRL:			printf("*%s = %s\n",result.c_str(),arg1.c_str());break;
		case PTRR:			printf("%s = *%s\n",result.c_str(),arg1.c_str());break;

		// array assign
		case ARRR:			printf("%s = %s[%s]\n",result.c_str(),arg1.c_str(),arg2.c_str());break;
		case ARRL:			printf("%s[%s] = %s\n",result.c_str(),arg1.c_str(),arg2.c_str());break;

		// Function call
		case PARAM:			printf("param %s\n",result.c_str());break;
		case CALL:			printf("%s = call %s,%s\n",result.c_str(),arg1.c_str(),arg2.c_str());break;
		case FUNCSTART:		printf("\n\n%s :\n",result.c_str());break;
		case FUNCEND:		printf("\n\n\n");break;

		// Equal
		case EQUAL:	
		case EQUALchar:
		case EQUALstr:
							printf("%s = %s\n",result.c_str(),arg1.c_str());break;



		//Conversion operators
		case CHAR2INT:
							printf("%s = (int) %s\n",result.c_str(),arg1.c_str());
							break;
		case INT2DOUBLE:
							printf("%s = (double) %s\n",result.c_str(),arg1.c_str());
							break;

		case CHAR2DOUBLE:
							printf("%s = (double) %s\n",result.c_str(),arg1.c_str());
							break;

		case INT2CHAR:
							printf("%s = (char) %s\n",result.c_str(),arg1.c_str());
							break;
		case DOUBLE2INT:
							printf("%s = (int) %s\n",result.c_str(),arg1.c_str());
							break;

		case DOUBLE2CHAR:
							printf("%s = (char) %s\n",result.c_str(),arg1.c_str());
							break;


		default:
							printf("\n");
	}
}


// quads print
void quads::print()
{
	int instr = -1;
	for(vector<quad>::iterator it = (this->quadarr).begin();it != (this->quadarr).end();it ++)
	{
		(*it).print(++instr);
	}
}



// emit quad
// input : result, operation type, argument1, argument2
void emit(string result,op_type op,string arg1,string arg2)
{
	
	quad nq = quad(op,result,arg1,arg2);
	(quadtrain->quadarr).push_back(nq);

}



// constructor for type_spec
// input: type, ptr to subtype, width of type
type_spec::type_spec(data_type x,type_spec *next,int width):type(x),width(width),ptr(next){
	//if(ptr!=NULL) ptr->print(); 
}

// print type_specifier
void type_spec::print()
{
	//VOID,INT,DOUBLE,CHAR,PTR,ARR
	switch(type)
	{
		case VOID:		printf("VOID");break;
		case INT:		printf("INT");break;
		case DOUBLE:	printf("DOUBLE");break;
		case CHAR:		printf("CHAR");break;
		case PTR:
						printf("ptr(");
						(this->ptr)->print();
						printf(")");
						break;
		case FUNCTION:
						printf("FUNCTION");
						break;
		case ARR:
						printf("array(%s,",tostr(this->width).c_str());
						(this->ptr)->print();
						printf(")");
						break;
	}
}


// constructor for sym_entry
// input: name of symbol entry, type, ptr to subtype, width of type
sym_entry::sym_entry(string name, data_type t, type_spec* ptr, int width): name(name)  {
	type = new  type_spec(t, ptr, width);
	nest_table = NULL;
	init = "";
	category = "";
	offset = 0;
	width = compute_size(type->type,type->ptr,type->width);
}


//print symbol in symbol table
void sym_entry::print()
{
	printf("name = %s , type = ",this->name.c_str());
	(this->type)->print();
	printf(" , size = %d ,  init = %s , offset = %d\n",this->width,this->init.c_str(),this->offset);
}



// update type of symbol entry
// input : pointer to new type
void sym_entry::update_type(type_spec *t)
{
	this->type = t;
	this->width = compute_size(this->type->type,this->type->ptr,this->type->width);
	
}

// initialize value of symbol entry
// input: string init
void sym_entry::initialize(string t){
	this->init = t;
}

// link symbol entry with symbol table
// pointer to symbol table
void sym_entry::linkst(symtab *t)
{
	this->nest_table = t;
}

// constructor for symbol table
// input : name of symbol table, pointer to parent table 
symtab::symtab(string name,symtab *parent):name(name),parent(parent)
{
	
	table.reserve(300);
	temp_count = 0;
}

// search a symbol in symbol table
// input: string  name of symbol
// output : boolean value for success

bool symtab::search(string a)
{
		for (vector<sym_entry>::iterator it=this->table.begin();it != this->table.end();it++)
		{
			if(strcmp(it->name.c_str(),a.c_str())==0)
				return true;
		}
		return false;
}



// lookup function for symbol table
// input: pointer to target symbol table and string name of symbol
// output: pointer to symbol in symbol table
sym_entry* lookup(symtab* cst,string a)
{

	symtab *cST = cst;
	
	while(cST != NULL)
	{
		
		for (vector<sym_entry>::iterator it=cST->table.begin();it != cST->table.end();it++)
		{
			
			if(strcmp(it->name.c_str(),a.c_str())==0)
				return &(*it);
		}
		cST = cST->parent;
	}

	
	sym_entry temp =  sym_entry(a);
	cst->table.push_back(temp);
	return &(cst->table.back());
	
}




// gentemp function for symbol table
// input: desired type, initial value
// output: pointer to generated symbol in symbol table
sym_entry* gentemp(type_spec t,string init)
{
	
	char str[20];
	sprintf(str, "t%02d", (currentST->temp_count)++);
	sym_entry temp = sym_entry(std::string(str),t.type,t.ptr,t.width);
	temp.init = init;
	temp.width = compute_size(t.type,t.ptr,t.width);
	temp.category = "local";
	currentST->table.push_back(temp);
	return &(currentST->table.back());
}


// update_offset of symbol table
void symtab::update_offset()
{
	int op = 0;
	for(vector<sym_entry>::iterator it = (this->table).begin();it != (this->table).end();it++)
	{
		it->offset = op;
		op = op + it->width;
	}
}

// print symbol table
void symtab::print()
{
	vector<symtab *> nested_tables; 
	if(parent!=NULL) printf("name = %s parent name = %s\n",this->name.c_str(),this->parent->name.c_str());
	else printf("name = %s\n",this->name.c_str());

	for(vector<sym_entry>::iterator it = this->table.begin();it != this->table.end();it++)
	{
		it->print();
		if(it->nest_table)
			nested_tables.push_back(it->nest_table);
	}

	printf("\n\n");
	for(vector<symtab *>::iterator it = nested_tables.begin();it != nested_tables.end();it++)
		{
			(*it)->print();
			printf("\n\n");
		}
}







// helper function makelist
// input: integer to be inserted into list
// output: new list with a single entry i
list<int> makelist(int i)
{
	list<int> mylist;

	mylist.push_back(i);
	return mylist;
}

// helper function merge
// input: two lists
// output: single list merging input lists
list<int> merge(list<int> p1,list<int> p2)
{
	printf("hello");
	p1.merge(p2);
	return p1;	
}

// helper function backpatch
// input: list and target address
// definition: stores integer i in result element of quads whose address is given in the list
void backpatch(list<int> p,int i)
{
	for(list<int>::iterator it = p.begin();it != p.end(); it++)
	{
		(quadtrain->quadarr)[*it].update(i);
	}	 
}

// helper function nextinstr
// output: returns address of next instruction in quadtrain
int nextinstr()
{
	return (quadtrain->quadarr).size();
}

// helper function for typecheck
// input: pointers to symbols whose types are to be checked, pointers to new symbols to be generated if conversion is needed
// output: boolean value of success 
bool typecheck(sym_entry *E1,sym_entry *E2,sym_entry **t1,sym_entry **t2)
{
	if((E1 == NULL && E2!=NULL) || ((E1 != NULL && E2==NULL))) return false;
	else return convert(E1,E2,t1,t2);
	
}


// helper function to convert from one type to another
// input: pointers to symbols, pointers to new symbols to be generated on conversion
// output: boolean value for success of conversion  
bool convert(sym_entry *e1,sym_entry *e2,sym_entry **t1,sym_entry **t2)
{

	if(e1->type->type == INT)
	{
		switch(e2->type->type)
		{
			case DOUBLE:	*t1 = x2Double(e1);
							*t2 = e2;
							return true;
							break;
			case INT:		*t1=e1;
							*t2=e2;
							return true;
							break;

			case CHAR:		*t1=e1;
							*t2=x2Int(e2);
							return true;
							break;

			default:		return false;
		}

	}
	if(e1->type->type == CHAR)
	{
		switch(e2->type->type)
		{
			case DOUBLE:	*t1 = x2Double(e1);
							*t2 = e2;
							return true;
							break;

			case CHAR:		*t1=e1;
							*t2=e2;
							return true;
							break;

			case INT:		*t2=e2;
							*t1=x2Int(e1);
							return true;
							break;
							
			default:		return false;
		}

	}


	if(e1->type->type == DOUBLE)
	{
		switch(e2->type->type)
		{
			case INT:		*t2 = x2Double(e2);
							*t1 = e1;
							return true;
							break;
			case DOUBLE:	*t1=e1;
							*t2=e2;
							return true;
							break;

			case CHAR:		*t2 = x2Double(e2);
							*t1 = e1;
							return true;
							break;
							
			default:		return false;
		}

	}
	return false;
}

// helper function to convert a symbol type into double
// input: pointer to symbol whose type is to be changed to double
// output: pointer to genrated symbol  
sym_entry* x2Double(sym_entry* s){
  sym_entry* t; 
  if(s->type->type==DOUBLE){
    return s;
  }
  if(s->type->type==INT){
    t=gentemp(type_spec(DOUBLE));
    emit(t->name,INT2DOUBLE,s->name);
    return t;
  }
  if(s->type->type==CHAR){
    t=gentemp(type_spec(DOUBLE));
    emit(t->name,CHAR2DOUBLE,s->name);
    return t;
  }
  return s;
}


// helper function to convert a symbol type to integer
// input: pointer to symbol whose type is to be changed to integer
// output: pointer to generated symbol
sym_entry* x2Int(sym_entry* s){
  sym_entry* t; 
  if(s->type->type==INT){
    return s;
  }
  if(s->type->type==DOUBLE){
    
    t=gentemp(type_spec(INT));
    emit(t->name,DOUBLE2INT,s->name);
    return t;
  }
  if(s->type->type==CHAR){
    t=gentemp(type_spec(INT));
    emit(t->name,CHAR2INT,s->name);
    return t;
  }
  return s;
}

// helper function to convert a symbol type to char
// input: pointer to symbol whose type is to be changed to char
// output: pointer to generated symbol 
sym_entry* x2Char(sym_entry* s){
  sym_entry* t; 
  if(s->type->type==CHAR){
    return s;
  }
  if(s->type->type==DOUBLE){
    
    t=gentemp(type_spec(CHAR));
    emit(t->name,DOUBLE2CHAR,s->name);
    return t;
  }
  if(s->type->type==INT){
    t=gentemp(type_spec(CHAR));
    emit(t->name,INT2CHAR,s->name);
    return t;
  }
  return s;
}

// constructor for expression
expr::expr()
{
	isarr = false;
	isptr = false;
}


// helper function to compute size of a given type
// input: data_type, pointer to subtype and width of given type
// output: size of given type
int compute_size(data_type t,type_spec *ptr,int width)
{
	//if(ptr!=NULL) ptr->print();
	switch(t)
	{

		case INT:
					return size_of_int;
					break;

		case CHAR:
					return size_of_char;
					break;

		case DOUBLE:
					return size_of_double;
					break;

		case PTR:	return size_of_pointer;
					break;
		case ARR:
					return width*compute_size(ptr->type,ptr->ptr,ptr->width);
					break;
		default:
					return 0;
					break;

	}
}

// helper function to convert an expression to boolean expression
// input: pointer to target expression
void conv2bool(expr *e1)
{
	if(e1->isbool == false){

		e1->falselist = makelist(nextinstr());
		emit("",EQop,e1->loc->name,"0");
		e1->truelist = makelist(nextinstr());
		emit("",GOTO);

	}
	e1->isbool = true;
}


//helper function to convert an expression to normal expression
//input: pointer to target expression 
void conv2exp(expr *e1)
{
	if(e1->isbool == true)
	{
		if(e1->loc == NULL)
			e1->loc = gentemp(type_spec(INT));
		backpatch(e1->falselist,nextinstr());
		emit(e1->loc->name,EQUAL,"0");
		backpatch(e1->truelist,nextinstr());
		emit(e1->loc->name,EQUAL,"1");

	}
	e1->isbool = false;
}











/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////




/*
Quad_array::Quad_array()
{
	quad_array = (Quads *)malloc(1000*sizeof(Quads));
	length = 1000;
	top = 0;
}

void Quad_array::insert(Quads new_quad)
{
	quad_array[top++] = new_quad;
}

void Quad_array::bp(std::list<int> p, int i)
{
	for (std::list<int>::iterator it=p.begin(); it!=p.end(); ++it)
		quad_array[*it].result = i ;
}

void Quad_array::increase_size()
{
	if(top == length)
		{
			length = length + 1000;
			quad_array = (Quads *)realloc(length,sizeof(Quads));
		}
}



Quad_array::~Quad_array()
{
	free(quad_array);
}



void Quad_array::print()
{
	for(int i=0;i<top;i++)
	{
		if(quad_array[i].arg2)
			
			{
				if(quad_array[i].op == "=[]")
					printf("\t%s = %s[%s]\n",quad_array[i].result, quad_array[i].arg1, quad_array[i].arg2);
				else if(quad_array[i].op == ">" or quad_array[i].op == ">=" or quad_array[i].op == "<" or quad_array[i].op == "<=" or quad_array[i].op == "==")
					printf("\tif %s %s %s goto %s\n",quad_array[i].arg1, quad_array[i].op, quad_array[i].arg2, quad_array[i].result);
				else
					printf("\t%s = %s %s %s\n",quad_array[i].result, quad_array[i].arg1, quad_array[i].op, quad_array[i].arg2);
			}
		else if(quad_array[i].op)
			
			printf("\t%s = %c %s\n",quad_array[i].result, quad_array[i].op, quad_array[i].arg1);
		else if(quad_array[i].arg1)
			
			printf("\t%s=%s\n",quad_array[i].result,quad_array[i].arg1);
		else 
			printf("\tgoto %s",quad_array[i].result);
	}
}


// call for global quad array
Quad_array quads;




std::list<int> makelist(int i)
{
	std::list<int> mylist;
	mylist.push_back(i);
	return mylist;
}


std::list<int> merge(std::list<int> p1,std::list<int> p2)
{
	p1.merge(p2);
	return p1;	
}



void backpatch(std::list<int> p, int i)
{
	// assumed quad array is declared
	quads.bp(p,i);
}




void emit(char *op,char *arg1,char *arg2,char *result)
{
	quads.increase_size();

	quad nq;
	nq.op = op;
	nq.arg1 = arg1;
	nq.arg2 = arg2;
	nq.result = result 
	quads.insert(nq);

}


void print_quad()
{
	quads.print();
}


*/


