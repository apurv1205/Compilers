

//#define BUFF 20

// filename  printInt.c++
int prints(char *buff) {
	int i = 0,bytes;

	while(buff[i]!='\0')
	{
		i++;
	}

	//buff[i] = '\n';
	bytes = i;

	__asm__ __volatile__ (
		"movl $1, %%eax \n\t"
		"movq $1, %%rdi \n\t"
		"syscall \n\t"
		:
		:"S"(buff), "d"(bytes)
	) ; // $4: write, $1: on stdin

	return bytes;
}





int printi(int n) {
	char buff[20], zero='0';
	int i=0, j, k, bytes;
	if(n == 0) buff[i++]=zero;
	else{
		if(n < 0) {
			buff[i++]='-';
			n = -n;
		}
		while(n){
			int dig = n%10;
			buff[i++] = (char)(zero+dig);
			n /= 10;
		}

		if(buff[0] == '-') j = 1;
		else j = 0;

		k=i-1;
		while(j<k){
			char temp=buff[j];
			buff[j++] = buff[k];
			buff[k--] = temp;
		}
	}

	buff[i]='\n';
	bytes = i+1;

	__asm__ __volatile__ (
		"movl $1, %%eax \n\t"
		"movq $1, %%rdi \n\t"
		"syscall \n\t"
		:
		:"S"(buff), "d"(bytes)
	) ; // $4: write, $1: on stdin

	return bytes;
}

int term(char c)
{
	if(c==' ' || c=='\t' || c=='\n' || c=='\v' || c=='\f' || c=='\r')
		return 1;
	else 
		return 0;   
}


int readi(int *ep)
{
	*ep = 0;
	int bytes = 100,len,i,sign=0,first=0;
	long long int temp,maxint = 2147483648,divi;
	char buff[100];


	__asm__ __volatile__ (
		"movl $0, %%eax \n\t"
		"movq $0, %%rdi \n\t"
		"syscall \n\t"
		:
		:"S"(buff), "d"(bytes)
	) ;



	for(i=0;i<100;i++)
		if(buff[i]<'0' || buff[i]>'9')
		{
			if(buff[i] == '-' && i==0){
				sign = 1;
				first = 1;
				continue;
			}
			else if(buff[i] == '+' && i==0)
			{
				first = 1;
				continue;
			}
			if(term(buff[i])) {
				break;
			}
			*ep = 1;
			return -4294967296;
		}


	len = i;
	temp=0;
	i = first;
	for(;i<len;i++)
		temp = temp*10 + (buff[i] - '0');

	if(sign) return (int)(-1*temp);
	else return (int)temp;

}







int readf(float *fp)
{
	char buff[100];
	int bytes = 100,len,i,type1=1,type2=1,decpos=-1,epos=-2,sign1=0,sign2=0,first=0;


	__asm__ __volatile__ (
		"movl $0, %%eax \n\t"
		"movq $0, %%rdi \n\t"
		"syscall \n\t"
		:
		:"S"(buff), "d"(bytes)
	) ;


	if((buff[0]=='i' || buff[0]=='I') && (buff[1] == 'n' || buff[1] == 'N') && (buff[2] == 'f'|| buff[2]== 'F'))
	{
		*fp = 1.0/0;
		return 0;
	}
	else if((buff[0]=='n' || buff[0]=='N') && (buff[1] == 'a' || buff[1]=='A') && (buff[2] == 'n' || buff[0]=='N'))
	{
		*fp = 0.0/0.0;
		return 0;
	}

	else {
		for(i=0;i<100;i++)
		{
			if(buff[i]=='-' || buff[i]=='+')
			{
				if(i==0) first=1;
				if(i==0) sign1=(buff[i]=='-')?1:0;
			}
			if(buff[i]=='.')
				decpos = i;
			if(buff[i]=='e' || buff[i]=='E')
				epos = i;
			if(term(buff[i]))
				break;
		}


		len = i;


		//printf("%d\n",epos);

		//check if it of type 1
		for(i=first;i<len;i++)
		{
			if(buff[i]<'0' || buff[i]>'9')
			{
				if(buff[i]=='.' && i==decpos)
				{
					continue;
				}
					
				type1=0;
				break;
				
			}
		}


		//check if it of type 2
		for(i=first;i<len;i++)
		{
			if(buff[i]<'0' || buff[i]>'9')
			{
				if(buff[i]=='.' && i==decpos)
				{
					continue;
				}
				if((buff[i]=='e' || buff[i]=='E') && i==epos)
				{
					continue;
				}
				if((buff[i]=='+' || buff[i]=='-') && (i==epos+1))
				{
					continue;
				}
				
			//	printf("%c",buff[i]);
				type2 = 0;
				break; 
				
			}
		}



		if(decpos > epos)
			type2=0;


		if((!type1 && !type2) || !len || (!type1 && epos==-2))
			return 1;

		else if(type1)
		{
			if(decpos==-1)
				decpos=len;
			double temp=0;
			double ego = 0;
			//printf("%d",decpos);
			for(i=first;i<decpos;i++)
			{

				temp = temp*10 + (buff[i]-'0');
				//printf("%lld\n",temp);
			}
			for(i=len-1;i>decpos;i--)
			{
				ego = ego/10 + (buff[i]-'0');
				//printf("%lf\n",ego);
			}
			ego = (double)temp+(ego/10);

			if(sign1) *fp = -1 * (float)ego;
			else *fp = (float)ego;

			return 0;
		}

		else if(type2)
		{
			if(decpos==-1)
				decpos=epos;
			double temp=0;
			int power = 0;
			double ego = 0;
			if(buff[0]=='-')
				sign1=1;
			else sign1=0;
			for(i=first;i<decpos;i++)
			{
				temp = temp*10 + (buff[i]-'0');
				//printf("%lld\n",temp);
			}
			for(i=epos-1;i>decpos;i--)
			{
				ego = ego/10 + (buff[i]-'0');
				//printf("%lf\n",ego);
			}
			ego = (double)temp+(ego/10);
			//printf("ego=%lf\n",ego);
			for(i=epos+1;i<len;i++)
			{
				if(i==epos+1 && buff[i]=='+')
					sign2=0;
				else if(i==epos+1 && buff[i]=='-')
					sign2=1;
				else{
					power = power*10 + (buff[i]-'0');
				}
			}
			if(sign2) power*=-1;




	        if(power <= 0) {
	        	while(power<0){
	        		ego = ego/10;
	        		power++;
	        	}
	        }
	        else {
	        	while(power>0)
	        	{
	        		ego = ego*10;
	        		//printf("%lf",ego);
	        		power--;
	        	}
	        }

	        if(sign1) *fp = -1 * (float)ego;
			else *fp = (float)ego;

			return 0;
		}

	}


}







int printd(float f)
{
	//cout<<f<<"\n";
	int i=0,j,decpos,k,bytes,size;
	long long whole;
	float temp,asd;
	char buff[100];
	char zero = '0';



	if(f ==1.0/0)
	{
		buff[0] = 'i';
		buff[1] = 'n';
		buff[2] = 'f';
		buff[3] = '\n';
		bytes = 4;
	}
	else if(!(f==f))
	{
		buff[0] = 'n';
		buff[1] = 'a';
		buff[2] = 'n';
		buff[3] = '\n';
		bytes = 4;
	}
	else {
	size = 0;

	if(f>1e18 || f<-1e18)
	{
		if(f<0) asd = -f;
		else asd = f;
		size=size+18;
		f = f*(1e-18);
	}	


	whole = (long long)f;
	//printf("%ll\n",f);
	temp = f - whole;
	//cout<<whole<<"\n";
	if(temp<0) temp = temp*(-1);

	if(whole == 0) buff[i++]=zero;
		else{
			if(whole < 0) {
				buff[i++]='-';
				whole = -whole;
				//max = 9;
			}
			//else max = 8;
			while(whole){
				int dig = whole%10;
				buff[i++] = (char)(zero+dig);
				whole /= 10;
			}

			if(buff[0] == '-') j = 1;
			else j = 0;

			k=i-1;
			while(j<k){
				char temp=buff[j];
				buff[j++] = buff[k];
				buff[k--] = temp;
			}
		}

		decpos = i;
		buff[i++] = '.';
		//cout<<decpos<<" "<<i<<"\n";

		for(j=0;j<7;j++)
		{
			//cout<<temp<<"\n";
			temp = temp*10;
			buff[i++] = (char)(zero + (int)(temp));
			temp = temp - (int)temp;
		}
		//cout<<buff[i-1]<<"\n";

		//if(i!=decpos+2){
			k = i-1;
			//cout<<i<<" "<<decpos<<"\n";
			if(buff[k] > '5' || (buff[k]=='5' && (buff[k-1]-'0')%2))
			{

				//cout<<buff[k]<<"\n";
				if(buff[k-1] < '9'){
					buff[k-1] = (char)(buff[k-1]+1);
				}
				else {
					//search for character < '9' after decimal
					int check=0;
					for(j=decpos+1;j<k-1;j++){
						if(buff[j] < '9'){
							check = 1;
							break;
						}					
					}
					if(check == 1)
					{
						j = k-1;
						while(buff[j] == '9')
						{
							buff[j] = zero;
							j--;
						}
						buff[j] = (char)(buff[j]+1);
					}
				}
			}
			i--;

		 if(size>0){
			 for(j=decpos+1;j<= decpos+size && j<i;j++)
			 {
			 	buff[j-1] = buff[j];
			 }
			 if(size > 6) {
			 	for(j=i;j<i+size-6;j++)
			 	{
			 		buff[j-1] = zero;
			 	}
			 }

			 buff[j] = '.';
			 i=j+1;
			 if(size>6)
			 {
			 	for(j=0;j<6;j++)
			 		buff[i++] = '0';
			 }
		}

		 //buff[i]='\n';

		 bytes = i;
	}

	 __asm__ __volatile__ (
		"movl $1, %%eax \n\t"
		"movq $1, %%rdi \n\t"
		"syscall \n\t"
		:
		:"S"(buff), "d"(bytes)
	) ; // $4: write, $1: on stdin

	return bytes;


}
